export default async (req, res) => {
  const { reqHandler } = await import('../dist/ngx-fullstack-ecommerce/server/server.mjs');
  return reqHandler(req, res);
};
