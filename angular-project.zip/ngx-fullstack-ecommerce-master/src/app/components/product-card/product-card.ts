import { Component, ChangeDetectionStrategy, input, inject, computed } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import { Product } from '../../models/product';
import { EcommerceStore } from '../../ecommerce-store';
import { StarRating } from '../../components/star-rating/star-rating';
import { RouterLink } from '@angular/router';
import { MatIconButton } from '@angular/material/button';
import { ResponsiveManager } from '../../services/responsive-manager';

@Component({
  selector: 'app-product-card',
  imports: [MatButton, MatIcon, StarRating, RouterLink],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div
      class="relative bg-white cursor-pointer rounded-xl overflow-hidden shadow-lg transition-all duration-200 ease-out hover:-translate-y-1 hover:shadow-xl flex flex-col h-full"
    >
      <img
        [src]="product().imageUrl"
        [alt]="product().name"
        class="w-full h-[300px] object-cover rounded-t-xl"
        [style.view-transition-name]="
          responsiveManager.largeWidth() ? 'product-image-' + product().id : null
        "
        [routerLink]="['/product', product().id]"
      />

      <ng-content />

      <!-- Product Info -->
      <div class="p-5 flex flex-col flex-1">
        <h3
          class="text-lg font-semibold text-gray-900 mb-2 leading-tight"
          [routerLink]="['/product', product().id]"
        >
          {{ product().name }}
        </h3>
        <p class="text-sm text-gray-600 mb-4 flex-1 leading-relaxed">{{ product().description }}</p>

        <app-star-rating class="mb-3" [rating]="product().rating">
          ({{ product().reviewCount }})
        </app-star-rating>

        <!-- Stock Status -->
        <div
          class="text-sm font-medium mb-4"
          [class]="product().inStock ? 'text-green-600' : 'danger'"
        >
          {{ product().inStock ? 'In Stock' : 'Out of Stock' }}
        </div>

        <!-- Price and Add to Cart -->
        <div class="flex items-center justify-between mt-auto">
          <span class="text-2xl font-bold text-gray-900">\${{ product().price }}</span>
          <button
            matButton="filled"
            class="flex items-center gap-2"
            [disabled]="!product().inStock"
            (click)="store.addToCart(product())"
          >
            <mat-icon>shopping_cart</mat-icon>
            Add to Cart
          </button>
        </div>
      </div>
    </div>
  `,
  styles: ``,
})
export class ProductCard {
  product = input.required<Product>();
  store = inject(EcommerceStore);

  responsiveManager = inject(ResponsiveManager);

  isInWishlist = computed(() => this.store.wishlistItems().find((p) => p.id === this.product().id));

  toggleWishlist(product: Product) {
    if (this.isInWishlist()) {
      this.store.removeFromWishlist(product);
    } else {
      this.store.addToWishlist(product);
    }
  }
}
