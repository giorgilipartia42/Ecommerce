import { Component, inject } from '@angular/core';
import { MatToolbar } from '@angular/material/toolbar';
import { MatIcon } from '@angular/material/icon';
import { MatIconButton } from '@angular/material/button';
import { EcommerceStore } from '../../ecommerce-store';
import { ResponsiveManager } from '../../services/responsive-manager';
import { SearchBar } from '../search-bar/search-bar';
import { HeaderActions } from '../header-actions/header-actions';

@Component({
  selector: 'app-header',
  imports: [MatToolbar, MatIcon, MatIconButton, SearchBar, HeaderActions],
  template: `
    <mat-toolbar class="w-full elevated py-2">
      <div class="max-w-[1200px] mx-auto w-full flex items-center justify-between">
        <div class="flex items-center gap-2">
          <button matIconButton (click)="responsiveManager.toggleSideNav()">
            <mat-icon>menu</mat-icon>
          </button>
          <span>Modern Store</span>
        </div>
        <app-search-bar />
        <app-header-actions />
      </div>
    </mat-toolbar>
  `,
  host: {
    class: 'relative z-10 view-transition-name:header',
  },
  styles: ``,
})
export class Header {
  protected store = inject(EcommerceStore);
  responsiveManager = inject(ResponsiveManager);
}
