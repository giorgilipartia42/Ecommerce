import { inject, Injectable } from '@angular/core';
import { HotToastService } from '@ngxpert/hot-toast';

@Injectable({
  providedIn: 'root',
})
export class Toaster {
  toasterService = inject(HotToastService);

  success(message: string) {
    this.toasterService.success(message);
  }

  error(message: string) {
    this.toasterService.error(message);
  }

  loading(message: string) {
    this.toasterService.loading(message);
  }
}
