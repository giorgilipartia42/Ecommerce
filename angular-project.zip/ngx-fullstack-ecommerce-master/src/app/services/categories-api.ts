import { Injectable, signal } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class CategoriesApi {
  private categories = ['all', 'electronics', 'clothing', 'accessories', 'home'];

  getCategories() {
    return this.categories;
  }
}
