import { Injectable, InjectionToken, inject } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { DOCUMENT } from '@angular/common';
import { Router } from '@angular/router';
import { SeoData } from '../models/seo-data';

export const REQUEST = new InjectionToken<Request>('REQUEST');

@Injectable({
  providedIn: 'root',
})
export class SeoManager {
  title = inject(Title);
  meta = inject(Meta);
  document = inject(DOCUMENT);
  request = inject(REQUEST, { optional: true }) as Request | undefined;
  router = inject(Router);

  private readonly siteName = 'Modern Store';
  private readonly defaultImage =
    'https://dummyimage.com/600x400/ffffff/030003.png&text=Modern+Store';

  updateSeoTags(data: SeoData): void {
    this.title.setTitle(`${data.title} | ${this.siteName}`);

    // Standard meta tags
    this.meta.updateTag({ name: 'description', content: data.description });

    // Generate full URL:
    // - On the server: use REQUEST to build origin
    // - On the browser: fall back to window.location.origin
    let origin = '';
    if (this.request) {
      const headers = this.request.headers as Headers | undefined;
      const protocol =
        (headers?.get('x-forwarded-proto') || this.request.url.split(':')[0] || 'https') + '://';
      const host = headers?.get('x-forwarded-host') || headers?.get('host') || '';
      origin = host ? `${protocol}${host}` : '';
    } else if (typeof window !== 'undefined') {
      origin = window.location.origin;
    }
    const fullUrl = `${origin}${this.router.url}`;
    const imageUrl = data.image || this.defaultImage;

    // Canonical link tag
    let canonicalLink = this.document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
    if (!canonicalLink) {
      canonicalLink = this.document.createElement('link');
      canonicalLink.setAttribute('rel', 'canonical');
      this.document.head.appendChild(canonicalLink);
    }
    canonicalLink.setAttribute('href', fullUrl);

    // Open Graph tags
    this.meta.updateTag({ property: 'og:type', content: data.type || 'website' });
    this.meta.updateTag({ property: 'og:site_name', content: this.siteName });
    this.meta.updateTag({ property: 'og:title', content: data.title });
    this.meta.updateTag({ property: 'og:description', content: data.description });
    this.meta.updateTag({ property: 'og:url', content: fullUrl });
    this.meta.updateTag({ property: 'og:image', content: imageUrl });
    this.meta.updateTag({ property: 'og:image:width', content: '1200' });
    this.meta.updateTag({ property: 'og:image:height', content: '630' });
    this.meta.updateTag({ property: 'og:locale', content: 'en_US' });
  }
}
