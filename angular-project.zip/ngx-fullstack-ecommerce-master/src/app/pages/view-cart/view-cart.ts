import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { TeaseWishlist } from './widgets/tease-wishlist/tease-wishlist';
import { ListCartItems } from './widgets/list-cart-items/list-cart-items';
import { SummarizeOrder } from '../../components/summarize-order/summarize-order';
import { EcommerceStore } from '../../ecommerce-store';
import { BackButton } from '../../components/back-button/back-button';
import { SignInDialog } from '../../components/sign-in-dialog/sign-in-dialog';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { MatButton } from '@angular/material/button';
import { SeoManager } from '../../services/seo-manager';

@Component({
  selector: 'app-view-cart',
  imports: [TeaseWishlist, ListCartItems, SummarizeOrder, BackButton, MatButton],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="mx-auto max-w-[1200px] py-6">
      <app-back-button class="mb-6" navigateTo="/products/all">Continue Shopping</app-back-button>

      <h1 class="text-3xl font-extrabold mb-4">Shopping Cart</h1>

      <app-tease-wishlist class="mb-6" />

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2">
          <app-list-cart-items />
        </div>
        <div>
          <app-summarize-order>
            <ng-container actionButtons>
              <button matButton="filled" class="w-full mt-6 py-3" (click)="proceedToCheckout()">
                Proceed to Checkout
              </button>
            </ng-container>
          </app-summarize-order>
        </div>
      </div>
    </div>
  `,
  styles: ``,
})
export default class ViewCart {
  store = inject(EcommerceStore);
  router = inject(Router);
  dialog = inject(MatDialog);
  seoManager = inject(SeoManager);

  constructor() {
    this.seoManager.updateSeoTags({
      title: 'Shopping Cart',
      description: 'View your shopping cart items',
    });
  }
  proceedToCheckout() {
    if (this.store.user()) {
      this.router.navigate(['/checkout']);
    } else {
      this.dialog.open(SignInDialog, {
        disableClose: true,
        data: {
          checkout: true,
        },
      });
    }
  }
}
