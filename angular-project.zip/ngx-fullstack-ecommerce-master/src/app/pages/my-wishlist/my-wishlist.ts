import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { EmptyWishlist } from './empty-wishlist/empty-wishlist';
import { EcommerceStore } from '../../ecommerce-store';
import { BackButton } from '../../components/back-button/back-button';
import { ProductCard } from '../../components/product-card/product-card';
import { MatIcon } from '@angular/material/icon';
import { MatIconButton } from '@angular/material/button';
import { SeoManager } from '../../services/seo-manager';

@Component({
  selector: 'app-my-wishlist',
  imports: [EmptyWishlist, BackButton, MatButton, ProductCard, MatIcon, MatIconButton],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="mx-auto max-w-[1200px] py-6 px-4">
      <app-back-button class="mb-6" navigateTo="/products/all">Continue Shopping</app-back-button>

      @if (store.wishlistItems().length > 0) {
        <!-- Wishlist Header -->
        <div class="flex justify-between items-center mb-6">
          <h1 class="text-2xl font-bold">My Wishlist</h1>
          <span class="text-gray-500 text-xl">{{ store.wishlistCount() }} items</span>
        </div>

        <!-- Grid of Wishlist Items -->
        <div class="responsive-grid">
          @for (product of store.wishlistItems(); track product.id) {
            <app-product-card [product]="product">
              <button
                class="!absolute top-3 right-3 z-10 !bg-white shadow-md transition-all duration-200 hover:scale-110 hover:shadow-lg"
                matIconButton
                (click)="store.removeFromWishlist(product)"
              >
                <mat-icon>delete</mat-icon>
              </button>
            </app-product-card>
          }
        </div>

        <!-- Clear Wishlist Button -->
        <div class="mt-8 flex justify-center">
          <button matButton="outlined" class="danger" (click)="store.clearWishlist()">
            Clear Wishlist
          </button>
        </div>
      } @else {
        <app-empty-wishlist />
      }
    </div>
  `,
})
export default class MyWishlist {
  protected store = inject(EcommerceStore);
  seoManager = inject(SeoManager);

  constructor() {
    this.seoManager.updateSeoTags({
      title: 'My Wishlist',
      description: 'View your wishlist items',
    });
  }
}
