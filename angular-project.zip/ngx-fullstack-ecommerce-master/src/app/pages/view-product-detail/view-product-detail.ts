import { Component, inject, input } from '@angular/core';
import { EcommerceStore } from '../../ecommerce-store';
import { Router } from '@angular/router';
import { ViewReviews } from './view-reviews/view-reviews';
import { ProductInfo } from './product-info/product-info';
import { BackButton } from '../../components/back-button/back-button';
import { SeoManager } from '../../services/seo-manager';

@Component({
  selector: 'app-view-product-detail',
  imports: [ViewReviews, ProductInfo, BackButton],
  template: `
    <div class="mx-auto max-w-[1200px] py-6">
      <app-back-button class="mb-6" (backClicked)="goBack()">Back to Products</app-back-button>

      @if (store.selectedProduct(); as product) {
        <div class="flex gap-8 mb-8">
          <img
            [src]="product.imageUrl"
            [alt]="product.name"
            class="w-[500px] h-[550px] object-cover rounded-lg"
            [style.view-transition-name]="'product-image-' + product.id"
          />
          <div class="flex-1">
            <app-product-info [product]="product" />
          </div>
        </div>
        <app-view-reviews [product]="product" />
      }
    </div>
  `,
  styles: ``,
})
export default class ViewProductDetail {
  productId = input.required<string>();
  store = inject(EcommerceStore);
  router = inject(Router);
  seoManager = inject(SeoManager);

  constructor() {
    this.store.setProductId(this.productId);
    this.store.setProductSeoTags(this.store.selectedProduct);
  }

  goBack() {
    this.router.navigate([`/products`, this.store.category()], {
      queryParams: this.store.searchTerm() ? { search: this.store.searchTerm() } : {},
    });
  }
}
