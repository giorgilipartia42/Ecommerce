import { Component, ChangeDetectionStrategy, signal, inject, computed, input } from '@angular/core';
import { MatSidenav, MatSidenavContainer, MatSidenavContent } from '@angular/material/sidenav';

import { TitleCasePipe } from '@angular/common';
import { ProductCard } from '../../components/product-card/product-card';
import { EcommerceStore } from '../../ecommerce-store';
import { CategoryMenu } from './category-menu/category-menu';
import { ResponsiveManager } from '../../services/responsive-manager';
import { ToggleWishlistButton } from '../../components/toggle-wishlist-button/toggle-wishlist-button';
import { SeoManager } from '../../services/seo-manager';

@Component({
  selector: 'app-products-grid',
  imports: [
    MatSidenavContainer,
    MatSidenav,
    MatSidenavContent,
    TitleCasePipe,
    ProductCard,
    CategoryMenu,
    ToggleWishlistButton,
  ],
  providers: [],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <mat-sidenav-container class="h-full">
      <mat-sidenav
        #sidenav
        [mode]="responsiveManager.sideNavMode()"
        (openedChange)="responsiveManager.sideNavOpened.set($event)"
        [opened]="responsiveManager.sideNavOpened()"
      >
        <app-category-menu />
      </mat-sidenav>

      <mat-sidenav-content class="bg-gray-100 p-6">
        <div class="flex items-center justify-between mb-6">
          <div>
            <h1 class="text-2xl font-bold text-gray-900">
              {{ store.category() | titlecase }}
            </h1>
            <p class="text-base text-gray-600 mt-1">
              {{ store.filteredProducts().length }} products found
              @if (store.searchTerm()) {
                for "{{ store.searchTerm() }}"
              }
            </p>
          </div>
        </div>

        <div class="responsive-grid">
          @for (product of store.filteredProducts(); track product.id) {
            <app-product-card [product]="product">
              <app-toggle-wishlist-button
                class="!absolute z-10 top-3 right-3 !bg-white shadow-md rounded-md transition-all duration-200 hover:scale-110 hover:shadow-lg"
                [product]="product"
                [style.view-transition-name]="'wishlist-' + product.id"
              />
            </app-product-card>
          }
        </div>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: ``,
})
export default class ProductsGrid {
  categoryName = input<string | undefined>('all');
  search = input<string | undefined>('');
  store = inject(EcommerceStore);
  responsiveManager = inject(ResponsiveManager);
  seoManager = inject(SeoManager);

  productsQueryParams = computed(() => ({
    category: this.categoryName() ?? 'all',
    searchTerm: this.search() ?? '',
  }));

  constructor() {
    this.store.setParams(this.productsQueryParams);
  }
}
