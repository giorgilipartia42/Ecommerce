import { Component, inject, signal } from '@angular/core';
import { MatListItem, MatNavList } from '@angular/material/list';
import { RouterLink } from '@angular/router';
import { EcommerceStore } from '../../../ecommerce-store';
import { TitleCasePipe } from '@angular/common';
import { CategoriesApi } from '../../../services/categories-api';

@Component({
  selector: 'app-category-menu',
  imports: [MatNavList, MatListItem, RouterLink, TitleCasePipe],
  template: `
    <div class="p-6">
      <h2 class="text-lg text-gray-900">Categories</h2>

      <mat-nav-list>
        @for (category of categories(); track category) {
          <mat-list-item
            [routerLink]="['/products', category]"
            [queryParams]="store.searchTerm() ? { search: store.searchTerm() } : {}"
            [activated]="category === store.category()"
            class="my-2"
          >
            <span
              matListItemTitle
              class="font-medium"
              [class]="category === store.category() ? 'text-white' : null"
              >{{ category | titlecase }}</span
            >
          </mat-list-item>
        }
      </mat-nav-list>
    </div>
  `,
  styles: ``,
})
export class CategoryMenu {
  store = inject(EcommerceStore);
  categoriesApi = inject(CategoriesApi);

  categories = signal<string[]>(this.categoriesApi.getCategories());
}
