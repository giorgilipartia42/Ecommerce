import { RenderMode, ServerRoute } from '@angular/ssr';
import { CategoriesApi } from './services/categories-api';
import { inject } from '@angular/core';

export const serverRoutes: ServerRoute[] = [
  {
    path: 'products/:categoryName',
    renderMode: RenderMode.Prerender,
    async getPrerenderParams() {
      const catService = inject(CategoriesApi);
      const names = catService.getCategories();
      return names.map((name) => ({ categoryName: name }));
    },
  },
  {
    path: 'wishlist',
    renderMode: RenderMode.Client,
  },
  {
    path: 'cart',
    renderMode: RenderMode.Client,
  },
  {
    path: 'checkout',
    renderMode: RenderMode.Client,
  },
  {
    path: 'order-success',
    renderMode: RenderMode.Client,
  },
  {
    path: 'product/:productId',
    renderMode: RenderMode.Server,
  },
  {
    path: '**',
    renderMode: RenderMode.Server,
  },
];
