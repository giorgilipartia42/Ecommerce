import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Header } from './layout/header/header';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Header],
  providers: [],
  template: `
    <app-header />
    <div class="h-[calc(100vh-64px)] overflow-y-auto">
      <router-outlet />
    </div>
  `,
  styles: ``,
})
export class App {}
